/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
     "./challenge/**/*.{html,js}"
   ],
  theme: {
    extend: {
      colors:{
       " grenat":"	#6e0b14 "
        
      }
    },
  },
  plugins: [],
}

